//
//  TODOLISTApp.swift
//  TODOLIST
//
//  Created by 袁钟盈 on 2025/5/12.
//

import SwiftUI

@main
struct TODOLISTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
